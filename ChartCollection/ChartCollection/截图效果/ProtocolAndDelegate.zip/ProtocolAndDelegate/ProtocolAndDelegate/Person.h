//
//  Person.h
//  ProtocolAndDelegate
//
//  Created by anyongxue on 2017/1/4.
//  Copyright © 2017年 cc. All rights reserved.
//

#import <Foundation/Foundation.h>

//协议写在哪里都无所谓
@protocol gotoBeijingDelegate <NSObject>

- (void)zairen;

@end

@interface Person : NSObject<gotoBeijingDelegate>

@property (nonatomic,weak)id <gotoBeijingDelegate> trafficToolsDelegate;

- (void)gotoBeijing;

@end
