//
//  Car.m
//  ProtocolAndDelegate
//
//  Created by anyongxue on 2017/1/4.
//  Copyright © 2017年 cc. All rights reserved.
//

#import "Car.h"

@implementation Car

- (void)zairen{
    
     NSLog(@"开车去北京");
}

@end
