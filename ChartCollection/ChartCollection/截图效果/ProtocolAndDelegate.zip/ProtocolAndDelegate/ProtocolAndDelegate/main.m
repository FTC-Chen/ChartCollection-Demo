//
//  main.m
//  ProtocolAndDelegate
//
//  Created by anyongxue on 2017/1/4.
//  Copyright © 2017年 cc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Car.h"
#import "Horse.h"

int main(int argc, const char * argv[]) {
    
    
    //签署协议必须实现的方法
    /*
    Person *p = [[Person alloc] init];
    
    Car *car = [[Car alloc] init];
    
    Horse *horse = [[Horse alloc] init];

    [p zairen];
    
    [car zairen];
    
    [horse zairen];
    */
    
    //使用代理的方式
    Person *p = [[Person alloc] init];
    
    Car *car = [[Car alloc] init];
    
    Horse *horse = [[Horse alloc] init];
    
    
    p.trafficToolsDelegate = car;
    
    [p gotoBeijing];
    
    
    p.trafficToolsDelegate = horse;
    
    [p gotoBeijing];
    
    
    
    
    return 0;
}
