//
//  Horse.m
//  ProtocolAndDelegate
//
//  Created by anyongxue on 2017/1/4.
//  Copyright © 2017年 cc. All rights reserved.
//

#import "Horse.h"

@implementation Horse

- (void)zairen{
    
    NSLog(@"骑马去北京");
}

@end
