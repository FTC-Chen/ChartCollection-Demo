//
//  Horse.h
//  ProtocolAndDelegate
//
//  Created by anyongxue on 2017/1/4.
//  Copyright © 2017年 cc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

@interface Horse : NSObject<gotoBeijingDelegate>


@end
